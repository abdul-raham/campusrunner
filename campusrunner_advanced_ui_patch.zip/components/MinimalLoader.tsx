'use client';

import Image from 'next/image';
import { motion } from 'framer-motion';

export default function MinimalLoader() {
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#F6F7FB]">
      <div className="flex flex-col items-center gap-4">
        <motion.div
          animate={{ scale: [1, 1.08, 1], rotate: [0, 4, -4, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
          className="flex h-16 w-16 items-center justify-center rounded-[24px] border border-[#E9E4FF] bg-white shadow-[0_20px_50px_rgba(98,0,238,0.12)]"
        >
          <Image src="/logo.png" alt="CampusRunner" width={34} height={34} className="rounded-xl" />
        </motion.div>
        <div className="h-1.5 w-24 overflow-hidden rounded-full bg-[#E9E4FF]">
          <motion.div
            animate={{ x: ['-100%', '100%'] }}
            transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
            className="h-full w-1/2 rounded-full bg-gradient-to-r from-[#6200EE] to-[#03DAC5]"
          />
        </div>
      </div>
    </div>
  );
}
