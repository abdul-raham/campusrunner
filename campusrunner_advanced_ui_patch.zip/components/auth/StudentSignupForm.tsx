'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/supabase/client';
import { Mail, Phone, Lock, User, ArrowRight } from 'lucide-react';
import Image from 'next/image';

export function StudentSignupForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({ full_name: '', email: '', phone: '', password: '', confirmPassword: '' });

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    try {
      setLoading(true);
      setError(null);
      const { data: authData, error: authError } = await supabase.auth.signUp({ email: formData.email, password: formData.password });
      if (authError) throw authError;
      if (!authData.user) throw new Error('Failed to create user');

      const { error: profileError } = await supabase.from('profiles').insert([{ id: authData.user.id, full_name: formData.full_name, email: formData.email, phone: formData.phone, role: 'student' }]);
      if (profileError) throw profileError;

      router.replace('/student');
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={onSubmit} className="space-y-5">
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[24px] border border-[#E9E4FF] bg-white shadow-sm">
          <Image src="/logo.png" alt="CampusRunner" width={34} height={34} className="rounded-xl" />
        </div>
        <h2 className="text-3xl font-black">Create student account</h2>
        <p className="mt-2 text-sm text-[#6B7280]">Open your wallet-ready student dashboard.</p>
      </div>
      {error && <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">{error}</div>}
      {[
        ['Full Name', 'full_name', 'John Doe', User],
        ['Email', 'email', 'your@email.com', Mail],
        ['Phone', 'phone', '+234 80 0000 0000', Phone],
      ].map(([label, key, placeholder, Icon]: any) => (
        <div key={key}>
          <label className="mb-2 block text-sm font-bold">{label}</label>
          <div className="relative">
            <Icon className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#6B7280]" />
            <input type={key === 'email' ? 'email' : 'text'} required placeholder={placeholder} value={(formData as any)[key]} onChange={(e) => setFormData({ ...formData, [key]: e.target.value })} className="w-full rounded-2xl border border-[#E9E4FF] bg-white px-12 py-4 text-sm font-medium outline-none focus:border-[#6200EE]" />
          </div>
        </div>
      ))}
      {['password', 'confirmPassword'].map((key) => (
        <div key={key}>
          <label className="mb-2 block text-sm font-bold">{key === 'password' ? 'Password' : 'Confirm Password'}</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#6B7280]" />
            <input type="password" required placeholder="••••••••" value={(formData as any)[key]} onChange={(e) => setFormData({ ...formData, [key]: e.target.value })} className="w-full rounded-2xl border border-[#E9E4FF] bg-white px-12 py-4 text-sm font-medium outline-none focus:border-[#6200EE]" />
          </div>
        </div>
      ))}
      <button type="submit" disabled={loading} className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#6200EE] py-4 font-black text-white shadow-xl shadow-[#6200EE]/20 disabled:opacity-70">
        {loading ? 'Creating Account...' : 'Create Account'} {!loading && <ArrowRight className="h-4 w-4" />}
      </button>
      <p className="text-center text-sm text-[#6B7280]">Already have an account? <a href="/login" className="font-bold text-[#6200EE]">Login</a></p>
    </form>
  );
}
