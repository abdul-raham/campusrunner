'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Eye, EyeOff, Mail, Lock, ArrowRight } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/supabase/client';

export function LoginFormComponent() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const { data, error: authError } = await supabase.auth.signInWithPassword({ email, password });
      if (authError) throw authError;
      if (!data.user) throw new Error('No user found for this account.');

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', data.user.id)
        .single();

      if (profileError) throw profileError;

      const role = profile?.role || 'student';
      router.replace(`/${role === 'admin' ? 'admin' : role}`);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to sign in right now.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-[24px] border border-[#E9E4FF] bg-white shadow-sm">
          <Image src="/logo.png" alt="CampusRunner" width={34} height={34} className="rounded-xl" />
        </div>
        <h1 className="text-3xl font-black tracking-tight text-[#0B0E11]">Welcome back</h1>
        <p className="mt-2 text-sm text-[#6B7280]">Login and continue where you stopped.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {error && <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-600">{error}</div>}

        <div>
          <label className="mb-2 block text-sm font-bold text-[#0B0E11]">Email</label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#6B7280]" />
            <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required placeholder="your@email.com" className="w-full rounded-2xl border border-[#E9E4FF] bg-white px-12 py-4 text-sm font-medium outline-none ring-0 focus:border-[#6200EE]" />
          </div>
        </div>

        <div>
          <label className="mb-2 block text-sm font-bold text-[#0B0E11]">Password</label>
          <div className="relative">
            <Lock className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-[#6B7280]" />
            <input value={password} onChange={(e) => setPassword(e.target.value)} type={showPassword ? 'text' : 'password'} required placeholder="••••••••" className="w-full rounded-2xl border border-[#E9E4FF] bg-white px-12 py-4 pr-12 text-sm font-medium outline-none ring-0 focus:border-[#6200EE]" />
            <button type="button" onClick={() => setShowPassword((s) => !s)} className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6B7280]">
              {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
        </div>

        <button disabled={isLoading} type="submit" className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#6200EE] px-5 py-4 text-base font-black text-white shadow-xl shadow-[#6200EE]/20 disabled:opacity-70">
          {isLoading ? 'Signing in...' : 'Login'} {!isLoading && <ArrowRight className="h-4 w-4" />}
        </button>
      </form>

      <p className="text-center text-sm text-[#6B7280]">
        New here? <Link href="/signup" className="font-bold text-[#6200EE]">Create account</Link>
      </p>
    </div>
  );
}
