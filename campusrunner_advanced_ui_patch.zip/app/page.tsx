'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { useEffect, useState } from 'react';
import MinimalLoader from '@/components/MinimalLoader';
import {
  ArrowRight,
  Bell,
  CheckCircle2,
  ClipboardList,
  Package,
  Pill,
  Printer,
  Shirt,
  ShoppingBasket,
  Sparkles,
  Star,
  Truck,
  Wallet,
  Zap,
  ShieldCheck,
  Menu,
} from 'lucide-react';

const services = [
  ['Gas Refill', Zap],
  ['Market Run', ShoppingBasket],
  ['Laundry Pickup', Shirt],
  ['Printing & Photocopy', Printer],
  ['Food Pickup', Package],
  ['Parcel Delivery', Truck],
  ['Pharmacy', Pill],
  ['Errand Assistant', ClipboardList],
] as const;

export default function HomePage() {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), 900);
    return () => clearTimeout(t);
  }, []);

  if (loading) return <MinimalLoader />;

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-40 border-b border-[#ECE9FF] bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-6">
          <Link href="/" className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#E9E4FF] bg-white shadow-sm">
              <Image src="/logo.png" alt="CampusRunner" width={26} height={26} className="rounded-lg" />
            </div>
            <div>
              <p className="text-lg font-black tracking-tight">CampusRunner</p>
              <p className="text-xs text-[#6B7280]">Campus errands, simplified</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-8 md:flex">
            <a href="#services" className="text-sm font-semibold text-[#6B7280] hover:text-[#0B0E11]">Services</a>
            <a href="#dashboard" className="text-sm font-semibold text-[#6B7280] hover:text-[#0B0E11]">Dashboard</a>
            <a href="#flow" className="text-sm font-semibold text-[#6B7280] hover:text-[#0B0E11]">How it works</a>
          </nav>

          <div className="hidden items-center gap-3 md:flex">
            <Link href="/login" className="rounded-2xl border border-[#E9E4FF] px-5 py-2.5 text-sm font-bold text-[#6200EE]">Login</Link>
            <Link href="/signup" className="rounded-2xl bg-[#6200EE] px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-[#6200EE]/20">Get Started</Link>
          </div>

          <button className="rounded-2xl border border-[#E9E4FF] p-2 md:hidden"><Menu className="h-5 w-5 text-[#6200EE]" /></button>
        </div>
      </header>

      <section className="mx-auto grid max-w-7xl gap-12 px-4 py-12 md:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:py-20">
        <div className="flex flex-col justify-center">
          <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} className="mb-5 inline-flex w-fit items-center gap-2 rounded-full border border-[#E9E4FF] bg-white px-4 py-2 text-sm font-bold text-[#6200EE]">
            <Sparkles className="h-4 w-4" /> Fintech-grade campus utility
          </motion.div>
          <motion.h1 initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }} className="max-w-3xl text-5xl font-black leading-[0.98] tracking-tight md:text-6xl">
            A cleaner way to manage <span className="text-[#6200EE]">campus errands</span>.
          </motion.h1>
          <motion.p initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }} className="mt-6 max-w-2xl text-lg leading-8 text-[#6B7280] md:text-xl">
            Students request tasks, runners fulfill them, and admins oversee everything with a mobile-first dashboard that feels fast, modern, and premium.
          </motion.p>
          <motion.div initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }} className="mt-8 flex flex-col gap-4 sm:flex-row">
            <Link href="/signup" className="inline-flex items-center justify-center gap-2 rounded-[20px] bg-[#6200EE] px-7 py-4 text-base font-black text-white shadow-xl shadow-[#6200EE]/20">
              Start Now <ArrowRight className="h-4 w-4" />
            </Link>
            <Link href="/login" className="inline-flex items-center justify-center rounded-[20px] border border-[#E9E4FF] bg-white px-7 py-4 text-base font-black text-[#0B0E11]">
              View Demo Flow
            </Link>
          </motion.div>
          <div className="mt-8 flex flex-wrap gap-3 text-sm font-semibold text-[#6B7280]">
            <span className="fin-badge rounded-full px-3 py-2">Verified runners</span>
            <span className="fin-badge rounded-full px-3 py-2">Wallet-ready UI</span>
            <span className="fin-badge rounded-full px-3 py-2">Mobile-first dashboard</span>
          </div>
        </div>

        <motion.div id="dashboard" initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} className="mx-auto w-full max-w-[430px] rounded-[32px] border border-[#ECE9FF] bg-white p-3 shadow-[0_30px_80px_rgba(98,0,238,0.12)]">
          <div className="rounded-[28px] bg-[#FBFBFF] p-4">
            <div className="mb-5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="rounded-2xl border border-[#E9E4FF] bg-white p-2.5"><Image src="/logo.png" alt="CampusRunner" width={22} height={22} className="rounded-lg" /></div>
                <div>
                  <p className="font-black">CampusRunner</p>
                  <p className="text-xs text-[#6B7280]">Student dashboard</p>
                </div>
              </div>
              <div className="rounded-xl bg-white p-2 shadow-sm"><Bell className="h-4 w-4 text-[#6200EE]" /></div>
            </div>

            <div className="rounded-[28px] bg-gradient-to-br from-[#6200EE] via-[#4F2EE8] to-[#03DAC5] p-5 text-white">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.2em] text-white/70">Wallet balance</p>
                  <p className="mt-2 text-4xl font-black">₦12,480</p>
                </div>
                <Wallet className="h-6 w-6 text-white/80" />
              </div>
              <div className="mt-5 flex items-center justify-between rounded-2xl bg-white/12 px-4 py-3 backdrop-blur">
                <p className="text-sm text-white/85">Ready for your next errand</p>
                <button className="rounded-xl bg-white px-4 py-2 text-sm font-black text-[#6200EE]">Top Up</button>
              </div>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3">
              {services.slice(0, 6).map(([label, Icon], i) => (
                <div key={label} className="rounded-2xl border border-[#E9E4FF] bg-white p-4 shadow-sm">
                  <div className="mb-3 flex items-center justify-between">
                    <div className="rounded-xl bg-[#F4ECFF] p-2.5"><Icon className="h-4 w-4 text-[#6200EE]" /></div>
                    {i < 3 && <span className="rounded-full bg-[#E6FFF9] px-2 py-1 text-[10px] font-black text-[#03A894]">POPULAR</span>}
                  </div>
                  <p className="text-sm font-black">{label}</p>
                  <p className="mt-1 text-xs text-[#6B7280]">Fast campus help</p>
                </div>
              ))}
            </div>

            <div className="mt-5 rounded-2xl border border-[#E9E4FF] bg-white p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-black">Current order</p>
                  <p className="mt-1 text-xs text-[#6B7280]">Printing & photocopy • In progress</p>
                </div>
                <span className="rounded-full bg-[#ECFDF3] px-3 py-1 text-xs font-black text-[#00A63E]">ON TRACK</span>
              </div>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center text-[11px] font-bold text-[#6B7280]">
                <div className="rounded-xl bg-[#F4ECFF] px-2 py-2 text-[#6200EE]">Created</div>
                <div className="rounded-xl bg-[#F4ECFF] px-2 py-2 text-[#6200EE]">Accepted</div>
                <div className="rounded-xl bg-[#ECFDF3] px-2 py-2 text-[#00A63E]">In progress</div>
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      <section id="services" className="mx-auto max-w-7xl px-4 py-10 md:px-6 md:py-16">
        <div className="mb-10 text-center">
          <p className="mb-3 text-sm font-black uppercase tracking-[0.18em] text-[#6200EE]">Core services</p>
          <h2 className="text-4xl font-black tracking-tight md:text-5xl">Built around real campus behavior</h2>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {services.map(([title, Icon]) => (
            <div key={title} className="fin-card rounded-[28px] p-6">
              <div className="mb-4 inline-flex rounded-2xl bg-[#F4ECFF] p-3"><Icon className="h-5 w-5 text-[#6200EE]" /></div>
              <h3 className="text-xl font-black">{title}</h3>
              <p className="mt-2 text-sm leading-6 text-[#6B7280]">Instantly familiar services students can order without confusion.</p>
            </div>
          ))}
        </div>
      </section>

      <section id="flow" className="mx-auto max-w-7xl px-4 py-10 md:px-6 md:py-16">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            ['01', 'Choose a service', 'Pick from food pickup, market run, laundry, printing, parcel delivery, pharmacy, gas, or custom errands.'],
            ['02', 'Submit your request', 'Enter your task details, hostel or pickup point, budget, and urgency in a few taps.'],
            ['03', 'Track completion', 'A runner accepts, the status updates move forward, and you confirm delivery in-app.'],
          ].map(([step, title, text]) => (
            <div key={step} className="fin-card rounded-[30px] p-7">
              <div className="mb-5 inline-flex rounded-2xl bg-[#F4ECFF] px-4 py-2 text-sm font-black text-[#6200EE]">Step {step}</div>
              <h3 className="text-2xl font-black">{title}</h3>
              <p className="mt-3 text-[#6B7280] leading-7">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-20 md:px-6">
        <div className="rounded-[36px] bg-[#0B0E11] px-6 py-12 text-white md:px-10">
          <div className="grid gap-6 lg:grid-cols-[1fr_auto] lg:items-center">
            <div>
              <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-bold text-white/80"><ShieldCheck className="h-4 w-4 text-[#03DAC5]" /> safer, cleaner, faster</p>
              <h2 className="text-4xl font-black tracking-tight md:text-5xl">Ready to launch the platform properly?</h2>
              <p className="mt-4 max-w-2xl text-white/70">This design direction is built to scale into the student, runner, and admin experiences without feeling like a template.</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row lg:flex-col">
              <Link href="/signup" className="rounded-2xl bg-white px-6 py-4 text-center font-black text-[#6200EE]">Create account</Link>
              <Link href="/login" className="rounded-2xl border border-white/15 bg-white/5 px-6 py-4 text-center font-black text-white">Login</Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
