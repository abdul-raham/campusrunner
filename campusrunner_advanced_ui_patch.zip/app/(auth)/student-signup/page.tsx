import { StudentSignupForm } from '@/components/auth/StudentSignupForm';

export default function StudentSignupPage() {
  return (
    <main className="min-h-screen px-4 py-10 md:px-6">
      <div className="mx-auto grid min-h-[calc(100vh-5rem)] max-w-6xl items-center gap-10 lg:grid-cols-[1fr_460px]">
        <div className="hidden lg:block">
          <p className="mb-4 text-sm font-black uppercase tracking-[0.2em] text-[#6200EE]">Student onboarding</p>
          <h1 className="text-5xl font-black tracking-tight">Create your CampusRunner wallet-first student account.</h1>
          <p className="mt-5 max-w-xl text-lg leading-8 text-[#6B7280]">Students get a premium dashboard with service cards, wallet balance, live order status, and faster repeat actions.</p>
        </div>
        <div className="fin-card rounded-[32px] p-8 md:p-10">
          <StudentSignupForm />
        </div>
      </div>
    </main>
  );
}
