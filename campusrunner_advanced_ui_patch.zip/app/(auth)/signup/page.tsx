'use client';

import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight, UserRound, Bike, Shield } from 'lucide-react';

export default function SignupChoicePage() {
  return (
    <main className="min-h-screen px-4 py-10 md:px-6">
      <div className="mx-auto max-w-5xl">
        <div className="mb-10 text-center">
          <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-[24px] border border-[#E9E4FF] bg-white shadow-sm">
            <Image src="/logo.png" alt="CampusRunner" width={34} height={34} className="rounded-xl" />
          </div>
          <p className="mb-3 text-sm font-black uppercase tracking-[0.2em] text-[#6200EE]">Choose your access</p>
          <h1 className="text-4xl font-black tracking-tight md:text-5xl">How do you want to use CampusRunner?</h1>
          <p className="mx-auto mt-4 max-w-2xl text-[#6B7280]">Start with the correct role so your routing, dashboard, and permissions match immediately.</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Link href="/student-signup" className="fin-card rounded-[30px] p-8 transition hover:-translate-y-1">
            <div className="mb-6 inline-flex rounded-2xl bg-[#F4ECFF] p-3"><UserRound className="h-6 w-6 text-[#6200EE]" /></div>
            <h2 className="text-3xl font-black">Join as Student</h2>
            <p className="mt-3 text-[#6B7280] leading-7">Create requests, fund your wallet, track order timelines, and manage campus errands with a mobile-first dashboard.</p>
            <span className="mt-6 inline-flex items-center gap-2 font-black text-[#6200EE]">Continue <ArrowRight className="h-4 w-4" /></span>
          </Link>

          <Link href="/runner-signup" className="fin-card rounded-[30px] bg-[#0B0E11] p-8 text-white transition hover:-translate-y-1">
            <div className="mb-6 inline-flex rounded-2xl bg-white/10 p-3"><Bike className="h-6 w-6 text-[#03DAC5]" /></div>
            <h2 className="text-3xl font-black">Join as Runner</h2>
            <p className="mt-3 text-white/70 leading-7">Accept jobs, toggle availability, monitor earnings, and stay productive with a darker operations dashboard.</p>
            <span className="mt-6 inline-flex items-center gap-2 font-black text-[#03DAC5]">Continue <ArrowRight className="h-4 w-4" /></span>
          </Link>
        </div>

        <div className="mt-6 rounded-[28px] border border-[#E9E4FF] bg-white p-5 text-center text-sm text-[#6B7280]">
          <Shield className="mx-auto mb-2 h-5 w-5 text-[#6200EE]" />
          Admin accounts should remain private and seeded manually in Supabase.
        </div>
      </div>
    </main>
  );
}
