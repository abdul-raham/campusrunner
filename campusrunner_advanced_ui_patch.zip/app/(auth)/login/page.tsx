import { LoginFormComponent } from '@/components/auth/LoginForm';

export default function LoginPage() {
  return (
    <main className="min-h-screen px-4 py-10 md:px-6">
      <div className="mx-auto grid min-h-[calc(100vh-5rem)] max-w-6xl items-center gap-10 lg:grid-cols-[1fr_460px]">
        <div className="hidden lg:block">
          <p className="mb-4 text-sm font-black uppercase tracking-[0.2em] text-[#6200EE]">CampusRunner access</p>
          <h1 className="text-5xl font-black tracking-tight">Login to the student, runner, or admin experience.</h1>
          <p className="mt-5 max-w-xl text-lg leading-8 text-[#6B7280]">A cleaner auth surface, faster routing, and a premium UI that matches the actual platform quality.</p>
        </div>
        <div className="fin-card rounded-[32px] p-8 md:p-10">
          <LoginFormComponent />
        </div>
      </div>
    </main>
  );
}
