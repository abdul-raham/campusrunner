import { RunnerSignupForm } from '@/components/auth/RunnerSignupForm';

export default function RunnerSignupPage() {
  return (
    <main className="min-h-screen px-4 py-10 md:px-6">
      <div className="mx-auto grid min-h-[calc(100vh-5rem)] max-w-6xl items-center gap-10 lg:grid-cols-[1fr_460px]">
        <div className="hidden lg:block">
          <p className="mb-4 text-sm font-black uppercase tracking-[0.2em] text-[#6200EE]">Runner onboarding</p>
          <h1 className="text-5xl font-black tracking-tight">Join as a runner and manage jobs in a cleaner dark UI.</h1>
          <p className="mt-5 max-w-xl text-lg leading-8 text-[#6B7280]">Runners get a fast operations dashboard built for earnings, availability, and job acceptance without friction.</p>
        </div>
        <div className="fin-card rounded-[32px] p-8 md:p-10">
          <RunnerSignupForm />
        </div>
      </div>
    </main>
  );
}
